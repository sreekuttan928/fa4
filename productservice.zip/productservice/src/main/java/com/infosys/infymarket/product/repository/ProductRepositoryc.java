package com.infosys.infymarket.product.repository;

import org.springframework.data.repository.CrudRepository;

import com.infosys.infymarket.product.entity.Product;
public interface ProductRepositoryc extends CrudRepository<Product, String>{

}