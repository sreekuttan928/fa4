package com.infosys.infymarket.product.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.infosys.infymarket.product.dto.ProductDTO;
import com.infosys.infymarket.product.entity.Product;
import com.infosys.infymarket.product.repository.ProductRepository;
import com.infosys.infymarket.product.repository.ProductRepositoryc;



@Service
public class ProductService {
	Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	ProductRepository productrepo;
	@Autowired
	ProductRepositoryc productrepoc;
	// fetch all product
	public List<ProductDTO> getAllProduct() {

		List<Product> products = productrepo.findAll();
		List<ProductDTO> productDTOs = new ArrayList<>();

		for (Product product : products) {
			ProductDTO productDTO = ProductDTO.valueOf(product);
			productDTOs.add(productDTO);
		}

		logger.info("Plan details : {}", productDTOs);
		return productDTOs;
	}

	// Fetches by product name
	public List<ProductDTO> getProductByName(@PathVariable String productname) {

		logger.info("Calldetails request for customer {}", productname);

		List<Product> product = productrepo.findByproductname(productname);
		List<ProductDTO> productDTO = new ArrayList<ProductDTO>();

		for (Product Pro : product) {
			productDTO.add(ProductDTO.valueOf(Pro));
		}
		logger.info("Calldetails for customer : {}", product);

		return productDTO;
	}
	//fetch by category
	public List<ProductDTO> getProductBycategory(@PathVariable String category) {

		logger.info("Calldetails request for customer {}", category);

		List<Product> product = productrepo.findBycategory(category);
		List<ProductDTO> productDTO = new ArrayList<ProductDTO>();

		for (Product Prod : product) {
			productDTO.add(ProductDTO.valueOf(Prod));
		}
		logger.info("Calldetails for customer : {}", product);
	
		return productDTO;
	}
	//update the stock
	public Product updateProductStock(Product product, String prodid) {
		Product existingProduct = productrepoc.findById(prodid).orElse(null);
		if(existingProduct != null) {
			existingProduct.setStock(product.getStock());
			return productrepoc.save(existingProduct); 
		}
		return null;
	}

}